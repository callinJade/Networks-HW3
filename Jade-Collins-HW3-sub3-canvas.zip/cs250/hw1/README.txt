Directions: a README.txt file containing a description of each file and any information you feel the TAs need
to grade your program.

I have two main files: Operations and helperMethods

The Operations file holds all of the main tasks and the main method that runs the program and all of the tasks.
Each method is named for the task it completes and all of the output statements are within these methods.

The helperMethods file holds all of the extra methods I created to successfully complete the tasks without 
cluttering the main task methods too much. It has methods like checkType which checks the type of the inputs,
all of my conversion methods, and my OR, AND, and XOR operations. A lot of the helperMethods call other helperMethods.