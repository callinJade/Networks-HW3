java cs250.hw2.Memory <size> <experiments> <seed>

Compile: javac cs250/hw2/Memory.java
Run: java cs250.hw2.Memory 25000000 1 42
Zip: zip -r Jade-Collins-HW2.zip cs250

There is one file associated with this program: Memory.java

Within this file there are several methods: main, task1, task2, and task3

The main method just calls each task using the arguments when running the program

The task methods are names for the tasks they perform. Each task method prints
the output at the end of the method. Each one parses the arguments it was called
with to an int or Integer, depending on the argument. All objects, calculations, 
and time keeping is done within each task method.